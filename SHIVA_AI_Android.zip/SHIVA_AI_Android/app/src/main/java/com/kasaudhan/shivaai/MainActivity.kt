package com.kasaudhan.shivaai

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    companion object {
        // After deploying backend, replace this URL with your HTTPS backend URL.
        private const val BACKEND_URL = "https://YOUR-BACKEND-URL/ask"
        private const val WAKE_PHRASES = "hey jarvis|hey shiva|हेलो जार्विस|हे शिवा"
    }

    private lateinit var statusText: TextView
    private lateinit var transcriptText: TextView
    private lateinit var answerText: TextView
    private lateinit var listenButton: Button
    private var speechRecognizer: SpeechRecognizer? = null
    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private var listeningEnabled = false
    private var waitingForCommand = false
    private var waitingUntil = 0L
    private val handler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            statusText.text = "इस मोबाइल पर Speech Recognition उपलब्ध नहीं है। Google ऐप/भाषा सेवा जाँचें।"
            listenButton.isEnabled = false
            return
        }
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { statusText.text = "सुन रहा हूँ… “Hey Jarvis” बोलें" }
            override fun onBeginningOfSpeech() { statusText.text = "आपकी आवाज़ सुन रहा हूँ…" }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { statusText.text = "आवाज़ समझ रहा हूँ…" }
            override fun onError(error: Int) {
                if (listeningEnabled) handler.postDelayed({ startListeningSafe() }, 700)
            }
            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val heard = matches?.firstOrNull().orEmpty().trim()
                if (heard.isNotBlank()) handleSpeech(heard)
                else if (listeningEnabled) handler.postDelayed({ startListeningSafe() }, 500)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        listenButton.setOnClickListener {
            if (listeningEnabled) stopListening()
            else {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100)
                } else {
                    listeningEnabled = true
                    listenButton.text = "सुनना बंद करें"
                    startListeningSafe()
                }
            }
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 32, 24, 24)
            setBackgroundColor(android.graphics.Color.rgb(7, 17, 31))
        }
        val title = TextView(this).apply {
            text = "SHIVA AI"
            textSize = 30f
            setTextColor(android.graphics.Color.rgb(65, 205, 255))
            gravity = Gravity.CENTER
        }
        val tagline = TextView(this).apply {
            text = "Your Personal Intelligence"
            textSize = 14f
            setTextColor(android.graphics.Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        statusText = TextView(this).apply {
            text = "शुरू करने के लिए बटन दबाएँ"
            textSize = 16f
            setTextColor(android.graphics.Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 16)
        }
        listenButton = Button(this).apply { text = "🎙️ SHIVA चालू करें" }
        transcriptText = TextView(this).apply {
            text = "आप: —"
            textSize = 16f
            setTextColor(android.graphics.Color.WHITE)
            setPadding(0, 20, 0, 10)
        }
        answerText = TextView(this).apply {
            text = "SHIVA: मैं आपकी मदद के लिए तैयार हूँ।"
            textSize = 17f
            setTextColor(android.graphics.Color.rgb(180, 230, 255))
            setPadding(0, 10, 0, 10)
        }
        val note = TextView(this).apply {
            text = "जागने के लिए “Hey Jarvis” कहें। यह संस्करण ऐप खुला रहने पर सुनता है।"
            textSize = 12f
            setTextColor(android.graphics.Color.LTGRAY)
            setPadding(0, 18, 0, 0)
        }
        root.addView(title)
        root.addView(tagline)
        root.addView(statusText)
        root.addView(listenButton)
        val scroll = ScrollView(this)
        val inner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(transcriptText)
            addView(answerText)
            addView(note)
        }
        scroll.addView(inner)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) {
            val result = tts.setLanguage(Locale("hi", "IN"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.language = Locale("en", "IN")
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            listeningEnabled = true
            listenButton.text = "सुनना बंद करें"
            startListeningSafe()
        } else {
            Toast.makeText(this, "आवाज़ के लिए Microphone permission ज़रूरी है।", Toast.LENGTH_LONG).show()
        }
    }

    private fun startListeningSafe() {
        if (!listeningEnabled || isFinishing) return
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Hey Jarvis कहें")
            }
            speechRecognizer?.startListening(intent)
        } catch (_: Exception) {
            handler.postDelayed({ startListeningSafe() }, 1000)
        }
    }

    private fun stopListening() {
        listeningEnabled = false
        waitingForCommand = false
        speechRecognizer?.cancel()
        listenButton.text = "🎙️ SHIVA चालू करें"
        statusText.text = "सुनना बंद है"
    }

    private fun handleSpeech(raw: String) {
        val heard = raw.lowercase(Locale.ROOT)
        transcriptText.text = "आप: $raw"
        val wakeRegex = Regex("(hey\\s*jarvis|hey\\s*shiva|हे\\s*जार्विस|हेलो\\s*जार्विस|हे\\s*शिवा)", RegexOption.IGNORE_CASE)
        val match = wakeRegex.find(heard)

        var command = raw
        if (match != null) {
            waitingForCommand = true
            waitingUntil = System.currentTimeMillis() + 15_000
            command = raw.removeRange(match.range).trim().trim(',', '.', '!', '?')
            if (command.isBlank()) {
                speak("हाँ, बोलिए।")
                return
            }
        } else if (!waitingForCommand || System.currentTimeMillis() > waitingUntil) {
            statusText.text = "जागने के लिए “Hey Jarvis” बोलें"
            handler.postDelayed({ startListeningSafe() }, 400)
            return
        } else {
            waitingForCommand = false
        }

        if (command.isBlank()) {
            speak("हाँ, बोलिए।")
            return
        }
        waitingForCommand = false
        runCommand(command)
    }

    private fun runCommand(command: String) {
        val c = command.lowercase(Locale.ROOT)
        when {
            c.contains("youtube") || c.contains("यूट्यूब") || c.contains("open youtube") || c.contains("यूट्यूब खोल") ->
                launchApp("com.google.android.youtube", "https://www.youtube.com", "YouTube")
            c.contains("whatsapp") || c.contains("व्हाट्सएप") ->
                launchApp("com.whatsapp", "https://www.whatsapp.com", "WhatsApp")
            c.contains("chrome") || c.contains("क्रोम") ->
                launchApp("com.android.chrome", "https://www.google.com", "Chrome")
            c.contains("maps") || c.contains("मैप") || c.contains("गूगल मैप") ->
                launchApp("com.google.android.apps.maps", "https://maps.google.com", "Google Maps")
            c.contains("gmail") || c.contains("जीमेल") ->
                launchApp("com.google.android.gm", "https://mail.google.com", "Gmail")
            c.startsWith("search ") || c.startsWith("सर्च ") || c.contains("google पर खोज") || c.contains("गूगल पर खोज") -> {
                val q = command.replace(Regex("(?i)^(search|सर्च)\\s*"), "")
                    .replace(Regex("(?i)^(google पर खोज|गूगल पर खोज)\\s*"), "").trim()
                openWebSearch(if (q.isBlank()) command else q)
            }
            else -> askBackend(command)
        }
    }

    private fun launchApp(packageName: String, fallbackUrl: String, label: String) {
        try {
            val launch = packageManager.getLaunchIntentForPackage(packageName)
            if (launch != null) {
                startActivity(launch)
                speak("$label खोल रहा हूँ।")
            } else {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(fallbackUrl)))
                speak("$label का वेब पेज खोल रहा हूँ।")
            }
        } catch (_: ActivityNotFoundException) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(fallbackUrl)))
        } catch (_: Exception) {
            speak("$label नहीं खुल पाया।")
        }
    }

    private fun openWebSearch(query: String) {
        val url = "https://www.google.com/search?q=" + URLEncoder.encode(query, "UTF-8")
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        speak("इंटरनेट पर खोज रहा हूँ।")
    }

    private fun askBackend(question: String) {
        if (BACKEND_URL.contains("YOUR-BACKEND-URL")) {
            answerText.text = "SHIVA: पहले backend deploy करके MainActivity.kt में BACKEND_URL बदलें। निर्देश README में हैं।"
            speak("पहले बैकएंड सेट करना होगा। README में निर्देश देखें।")
            handler.postDelayed({ startListeningSafe() }, 2500)
            return
        }
        statusText.text = "AI से जवाब ला रहा हूँ…"
        answerText.text = "SHIVA: सोच रहा हूँ…"
        executor.execute {
            var responseText: String
            try {
                val conn = (URL(BACKEND_URL).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 20_000
                    readTimeout = 60_000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
                val body = JSONObject().put("question", question).toString()
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
                val response = stream.bufferedReader().use { it.readText() }
                if (conn.responseCode !in 200..299) throw Exception("Backend HTTP ${conn.responseCode}")
                responseText = JSONObject(response).optString("answer", "मुझे जवाब नहीं मिला।")
                conn.disconnect()
            } catch (e: Exception) {
                responseText = "कनेक्शन नहीं हो पाया। Backend URL, इंटरनेट और API key जाँचें।"
            }
            runOnUiThread {
                answerText.text = "SHIVA: $responseText"
                statusText.text = "जवाब तैयार"
                speak(responseText)
            }
        }
    }

    private fun speak(text: String) {
        statusText.text = "जवाब बोल रहा हूँ…"
        if (ttsReady) {
            tts.stop()
            tts.speak(text.take(3000), TextToSpeech.QUEUE_FLUSH, null, "shiva_reply")
        }
        handler.postDelayed({ if (listeningEnabled) startListeningSafe() }, 2200)
    }

    override fun onDestroy() {
        listeningEnabled = false
        speechRecognizer?.destroy()
        if (::tts.isInitialized) tts.shutdown()
        executor.shutdownNow()
        super.onDestroy()
    }
}
