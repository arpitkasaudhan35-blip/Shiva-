SHIVA AI — Android JARVIS-style assistant (starter project)
==========================================================

यह Android Studio project है। इसमें:
- हिंदी speech recognition (Android Speech Recognizer)
- हिंदी में बोलकर जवाब (Android TextToSpeech)
- “Hey Jarvis” और “Hey Shiva” wake phrase (ऐप खुला रहने पर)
- YouTube, WhatsApp, Chrome, Maps, Gmail खोलने के commands
- Google web search
- OpenAI backend से AI जवाब; backend में web_search tool enabled है

महत्वपूर्ण सीमाएँ
-----------------
1. यह तैयार APK नहीं, source-code project है। APK बनाने के लिए Android Studio चाहिए।
2. Wake phrase केवल ऐप खुला रहने पर, और जब Android speech-recognition service काम कर रही हो, तब सुनने की कोशिश करता है। यह screen-off/background always-on hotword नहीं है।
3. Voice recognition के लिए फोन पर Google speech services/Internet और microphone permission की ज़रूरत हो सकती है।
4. AI जवाब के लिए OpenAI API key और अलग API billing आवश्यक है। ChatGPT subscription API credits नहीं देता।
5. API key कभी Android app में न डालें; उसे backend host पर secret/environment variable में रखें।
6. Backend को public deploy करते समय authentication/rate limiting जोड़ना बेहतर है; इस starter में public endpoint की अतिरिक्त सुरक्षा नहीं है।

भाग 1 — Backend deploy करें
---------------------------
1. backend folder को GitHub repository में upload करें।
2. Python web service host (जैसे Render या Railway) पर repository connect करें।
3. Root/build directory को backend folder पर set करें, अगर host यह setting देता है।
4. Start command: gunicorn app:app
5. Environment variable/Secret जोड़ें:
   OPENAI_API_KEY = आपकी OpenAI API key
   वैकल्पिक: OPENAI_MODEL = gpt-4.1-mini
6. Deploy के बाद service URL देखें। Browser में URL खोलने पर {"service":"SHIVA AI backend","status":"ok"} दिखना चाहिए।
7. URL के अंत में /ask endpoint है। उदाहरण: https://your-service.example/ask

भाग 2 — Android Studio में project खोलें
-----------------------------------------
1. Android Studio (कंप्यूटर/लैपटॉप पर) install करें।
2. ZIP extract करें।
3. Android Studio > Open > extracted SHIVA_AI_Android folder चुनें।
4. Gradle sync पूरा होने दें। Android SDK 35 install करने को कहे तो SDK Manager से install करें।
5. app/src/main/java/com/kasaudhan/shivaai/MainActivity.kt खोलें।
6. यह line खोजें:
   private const val BACKEND_URL = "https://YOUR-BACKEND-URL/ask"
7. इसे अपने deployed backend URL से बदलें, उदाहरण:
   private const val BACKEND_URL = "https://your-service.example/ask"
8. USB debugging enabled Android phone connect करें और Run दबाएँ।
   या Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
9. APK आम तौर पर app/build/outputs/apk/debug/app-debug.apk में बनेगा।
10. फोन में install करके microphone permission दें और “SHIVA चालू करें” दबाएँ।

उदाहरण commands
----------------
- “Hey Jarvis” — assistant जागेगा, फिर command बोलें।
- “Hey Jarvis, YouTube खोलो”
- “Hey Jarvis, WhatsApp खोलो”
- “Hey Jarvis, Chrome खोलो”
- “Hey Jarvis, Google पर खोज भारत की राजधानी”
- “Hey Jarvis, DNA क्या है?”

Troubleshooting
---------------
- AI जवाब नहीं: backend URL में /ask होना चाहिए; host पर OPENAI_API_KEY secret जाँचें।
- 401/invalid key: OpenAI API key सही करें।
- 429: API project quota/billing/limits जाँचें।
- आवाज़ नहीं: Android Settings में Speech Recognition/Google app और Hindi language check करें।
- Apps नहीं खुलते: app install है या नहीं जाँचें; fallback web page खुलेगा।
- “Hey Jarvis” हमेशा background में नहीं चलेगा — यह जानबूझकर इस starter की सीमा है।
भाग 3 — सिर्फ Android मोबाइल से Cloud APK build (GitHub Actions)
-----------------------------------------------------------------
इस ZIP में .github/workflows/build.yml जोड़ा गया है। यह workflow GitHub पर source upload करने के बाद APK build कर सकता है।

1. Browser में https://github.com खोलकर account बनाओ/Sign in करो।
2. + > New repository चुनो। नाम SHIVA-AI रखो; Public या Private चुन सकते हो।
3. Repository में Add file > Upload files चुनो।
4. ZIP को फोन में extract किए हुए folder के अंदर की सभी files/folders upload करो। ध्यान रहे .github folder भी upload हो।
5. Commit changes दबाओ।
6. Repository के Actions tab में जाओ। “Build SHIVA AI APK” workflow चुनो; अगर automatic run नहीं हुआ तो Run workflow दबाओ।
7. Build सफल होने पर run खोलो, नीचे Artifacts में SHIVA-AI-debug-APK डाउनलोड करो।
8. Artifact ZIP को Files app में extract करो; अंदर app-debug.apk मिलेगा। उस पर tap करके install करो।
9. Android पूछे तो केवल अपने बनाए APK के लिए इस स्रोत से install की अनुमति दो।

ध्यान:
- GitHub mobile web interface में hidden dot-folder (.github) upload करना मुश्किल हो सकता है। यदि workflow file upload नहीं होती, repository में Add file > Create new file से path `.github/workflows/build.yml` बनाकर ऊपर के workflow की सामग्री paste करें।
- इस project में Gradle wrapper नहीं है, इसलिए workflow hosted Gradle 8.9 इस्तेमाल करता है।
- AI उत्तर चलाने से पहले backend deploy करके BACKEND_URL set करना आवश्यक है।
