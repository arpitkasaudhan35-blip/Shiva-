import os
from flask import Flask, request, jsonify
from openai import OpenAI

app = Flask(__name__)
client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))

@app.get("/")
def home():
    return jsonify({"service": "SHIVA AI backend", "status": "ok"})

@app.post("/ask")
def ask():
    data = request.get_json(silent=True) or {}
    question = str(data.get("question", "")).strip()
    if not question:
        return jsonify({"error": "question is required"}), 400
    if not os.environ.get("OPENAI_API_KEY"):
        return jsonify({"error": "OPENAI_API_KEY is not configured"}), 500
    try:
        response = client.responses.create(
            model=os.environ.get("OPENAI_MODEL", "gpt-4.1-mini"),
            instructions=(
                "You are SHIVA, a helpful Android voice assistant. "
                "Answer in natural Hindi by default, briefly and clearly. "
                "If the user asks for current facts or online information, use web search. "
                "Never claim you performed actions on the phone; the Android app handles app-opening commands."
            ),
            input=question,
            tools=[{"type": "web_search"}],
        )
        return jsonify({"answer": response.output_text})
    except Exception:
        app.logger.exception("AI request failed")
        return jsonify({"error": "AI request failed. Check server logs and API configuration."}), 502

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "8000")))
